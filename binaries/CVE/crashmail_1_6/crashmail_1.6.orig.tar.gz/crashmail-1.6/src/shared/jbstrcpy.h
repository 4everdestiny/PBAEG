#ifndef SHARED_JBSTRCPY_H
#define SHARED_JBSTRCPY_H

bool jbstrcpy(char *dest,char *src,uint32_t maxlen,uint32_t *jbc);
bool jbstrcpyrest(char *dest,char *src,uint32_t maxlen,uint32_t *jbc);

#endif
