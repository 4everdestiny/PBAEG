#ifndef SHARED_TYPES_H
#define SHARED_TYPES_H

#ifndef NO_TYPEDEF_BOOL
typedef int bool;
#endif

#define FALSE 0
#define TRUE 1

#endif
