#ifndef SHARED_MYSTRNCPY_H
#define SHARED_MYSTRNCPY_H

#include "shared/types.h"

void mystrncpy(char *dest,char *src,uint32_t len);

#endif
