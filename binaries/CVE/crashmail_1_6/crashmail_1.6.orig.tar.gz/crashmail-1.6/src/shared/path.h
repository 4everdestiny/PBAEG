
void MakeFullPath(char *path,char *file,char *dest,uint32_t destsize);
char *GetFilePart(char *str);


