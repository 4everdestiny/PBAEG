#include <stdio.h>

#include <oslib/os.h>

bool osInit(void)
{
   return(TRUE);
}

void osEnd(void)
{
}

