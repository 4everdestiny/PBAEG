bool Scan(void);
bool ScanList(char *file);
bool ScanDotJam(char *file);
bool ScanArea(char *tagname);
