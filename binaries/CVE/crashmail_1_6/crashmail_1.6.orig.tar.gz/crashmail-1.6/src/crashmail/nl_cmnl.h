bool cmnl_nlStart(char *errbuf);
void cmnl_nlEnd(void);
bool cmnl_nlCheckNode(struct Node4D *node);
long cmnl_nlGetHub(struct Node4D *node);
long cmnl_nlGetRegion(struct Node4D *node);
