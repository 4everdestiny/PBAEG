bool TossFile(char *file);
bool TossDir(char *dir);

