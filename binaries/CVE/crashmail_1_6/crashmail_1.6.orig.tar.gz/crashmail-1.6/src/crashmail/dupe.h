#include "shared/types.h"

bool OpenDupeDB(void);
void CloseDupeDB(void);

bool CheckDupe(struct MemMessage *mm);



