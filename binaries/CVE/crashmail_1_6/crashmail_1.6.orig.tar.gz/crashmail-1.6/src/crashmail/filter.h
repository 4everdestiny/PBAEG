bool Filter(struct MemMessage *mm);
bool CheckFilter(char *filter,char *cfgerr);


