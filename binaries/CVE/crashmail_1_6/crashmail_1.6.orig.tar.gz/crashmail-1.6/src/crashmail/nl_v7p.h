bool v7p_nlStart(char *errbuf);
void v7p_nlEnd(void);
bool v7p_nlCheckNode(struct Node4D *node);
long v7p_nlGetHub(struct Node4D *node);
long v7p_nlGetRegion(struct Node4D *node);
