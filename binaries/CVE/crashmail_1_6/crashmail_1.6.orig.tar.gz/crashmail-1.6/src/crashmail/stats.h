bool ReadStats(char *file);
bool WriteStats(char *file);
