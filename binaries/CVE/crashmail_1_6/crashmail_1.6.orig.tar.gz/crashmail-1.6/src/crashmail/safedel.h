bool SafeDelete(char *file);
void ProcessSafeDelete(void);
